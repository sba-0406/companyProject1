// Main JS for shared interactions
document.addEventListener('DOMContentLoaded', () => {
    // 1. Dynamic Navbar & Role-based UI Helper
    const userJson = localStorage.getItem('user');
    if (userJson) {
        const user = JSON.parse(userJson);
        const navDiv = document.querySelector('.navbar div');

        if (navDiv) {
            const currentPath = window.location.pathname;

            // Build consistent nav links
            let navHtml = '';

            // Role specific links
            if (user.role === 'admin') {
                const isAdmin = currentPath === '/admin';
                navHtml += `<a href="/admin" id="admin-link" class="${isAdmin ? 'active' : ''}" style="color:var(--danger); font-weight:700;">Admin Panel</a>`;
            }

            // Common links
            const links = [
                { name: 'Dashboard', url: '/dashboard' },
                { name: 'My Reports', url: '/report' }
            ];

            links.forEach(l => {
                const isActive = currentPath === l.url;
                navHtml += `<a href="${l.url}" class="${isActive ? 'active' : ''}">${l.name}</a>`;
            });

            navHtml += `<a href="#" id="logoutBtn">Logout</a>`;

            navDiv.innerHTML = navHtml;

            // Add User Identity Badge
            const userBadge = document.createElement('span');
            userBadge.className = 'badge';
            userBadge.style.marginLeft = '20px';
            userBadge.style.background = 'rgba(255,255,255,0.05)';
            userBadge.style.border = '1px solid var(--border)';
            userBadge.innerText = `${user.name} | ${user.role.toUpperCase()}`;
            navDiv.appendChild(userBadge);
        }
    }

    // 2. Logout Logic (Dynamically attached)
    document.addEventListener('click', async (e) => {
        if (e.target && e.target.id === 'logoutBtn') {
            e.preventDefault();
            try {
                await fetch('/api/auth/logout', { credentials: 'include' });
                localStorage.removeItem('user');
                window.location.href = '/';
            } catch (err) {
                console.error(err);
            }
        }
    });

    // 3. Login Flow
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                const res = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password }),
                    credentials: 'include'
                });
                const data = await res.json();

                if (data.success) {
                    localStorage.setItem('user', JSON.stringify(data.data));
                    window.location.href = '/dashboard';
                } else {
                    alert(data.error || 'Login Failed');
                }
            } catch (err) {
                console.error(err);
                alert('An error occurred during login');
            }
        });
    }
});
