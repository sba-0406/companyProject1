const express = require('express');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const path = require('path');

// Load env vars
dotenv.config();

// Connect to database
const connectDB = require('./config/db');
connectDB();

// Register Models
require('./models/User');
require('./models/Rubric');
require('./models/Scenario');
require('./models/SimulationResponse');

const app = express();

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Cookie parser
app.use(cookieParser());

// Enable CORS
app.use(cors());

// Set static folder for public assets
app.use(express.static(path.join(__dirname, '../../frontend/public')));

// Set View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../../frontend/views'));

// Route files
const auth = require('./routes/authRoutes');
const scenarios = require('./routes/scenarioRoutes');
const simulation = require('./routes/simulationRoutes');
const reports = require('./routes/reportRoutes');
const admin = require('./routes/adminRoutes');

// Mount routers
app.use('/api/auth', auth);
app.use('/api/scenarios', scenarios);
app.use('/api/simulation', simulation);
app.use('/api/reports', reports);
app.use('/api/admin', admin);

// View Routes (Simple rendering for now)
app.get('/', (req, res) => res.render('login')); // Default to login
app.get('/dashboard', (req, res) => res.render('dashboard'));
app.get('/scenario/:id', (req, res) => res.render('scenario', { scenarioId: req.params.id }));
app.get('/report', (req, res) => res.render('report'));
app.get('/admin', (req, res) => res.render('admin'));

module.exports = app;
