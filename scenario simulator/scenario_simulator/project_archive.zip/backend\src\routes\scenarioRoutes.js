const { getScenarios, getScenario, createScenario, getUniqueRoles } = require('../controllers/scenarioController');
const { protect } = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware'); // Alias for consistent naming if needed

const router = express.Router();

router.use(protect);

router.get('/roles', getUniqueRoles);
router.get('/', getScenarios);
router.get('/:id', getScenario);
router.post('/', role.authorize('admin'), createScenario);

module.exports = router;
