const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Scenario = require('../models/Scenario');
const Rubric = require('../models/Rubric');
const User = require('../models/User');

dotenv.config({ path: __dirname + '/../../../.env' });

async function seed() {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Clearing old data...');
    await Scenario.deleteMany({});
    await Rubric.deleteMany({});

    const r = await Rubric.create({ name: 'General Assessment', competencies: [] });

    console.log('Creating diverse scenarios...');
    const data = [
        // DEVELOPER
        {
            title: 'System Architecture Challenge',
            jobRole: 'Developer',
            difficulty: 'Medium',
            description: 'A major social network is experiencing delays during peak hours. You need to propose a scaling strategy.',
            stages: [
                { type: 'mcq', prompt: 'Where is the most likely bottleneck in a standard monolithic app?', options: ['Database I/O', 'Frontend CSS', 'Static Assets'] },
                { type: 'text', prompt: 'Your database is locking up. How do you implement horizontal scaling for the data layer?' }
            ]
        },
        {
            title: 'API Security Breach',
            jobRole: 'Developer',
            difficulty: 'Hard',
            description: 'A security researcher found an IDOR vulnerability in your user profile endpoint. Act fast.',
            stages: [
                { type: 'ranking', prompt: 'Rank your response steps:', options: ['Fix the bug', 'Notify stakeholders', 'Check if data was leaked', 'Revoke API keys'] },
                { type: 'text', prompt: 'Explain how you will prevent this specific vulnerability in the future using middleware.' }
            ]
        },
        {
            title: 'Legacy Code Migration',
            jobRole: 'Developer',
            difficulty: 'Medium',
            description: 'You are tasked with moving a 10-year old PHP app to a modern Microservices architecture.',
            stages: [
                { type: 'text', prompt: 'How do you handle shared user data during the transition without downtime?' }
            ]
        },

        // TEAM LEAD
        {
            title: 'The Burnout Crisis',
            jobRole: 'Team Lead',
            difficulty: 'Medium',
            description: 'Your best developer has missed three standups and seems disengaged. A major deadline is in 4 days.',
            stages: [
                { type: 'mcq', prompt: 'How do you approach the first conversation?', options: ['Direct performance warning', 'Informal 1:1 welfare check', 'Assign their tasks to someone else'] },
                { type: 'text', prompt: 'The developer admits they are burnt out but feels guilty. What specifically do you say to unblock the project and help them?' }
            ]
        },
        {
            title: 'Architectural Argument',
            jobRole: 'Team Lead',
            difficulty: 'Hard',
            description: 'Two senior devs are deadlocked on using GraphQL vs REST. The team is getting frustrated with the delay.',
            stages: [
                { type: 'ranking', prompt: 'Rank the decision factors:', options: ['Developer Experience', 'Performance', 'Library Support', 'Learning Curve'] },
                { type: 'text', prompt: 'Draft a short email to the team announcing the final decision while validating both viewpoints.' }
            ]
        },
        {
            title: 'New Hire Onboarding',
            jobRole: 'Team Lead',
            difficulty: 'Easy',
            description: 'A junior dev is joining tomorrow. Your previous onboarding process was non-existent.',
            stages: [
                { type: 'text', prompt: 'List 3 specific technical milestones for their first week.' }
            ]
        },

        // PROJECT MANAGER
        {
            title: 'Scope Creep Nightmare',
            jobRole: 'Project Manager',
            difficulty: 'Hard',
            description: 'The client just added 3 "must-have" features 1 week before launch. The dev team says it is impossible.',
            stages: [
                { type: 'mcq', prompt: 'Priority?', options: ['Say NO clearly', 'Ask for more budget', 'Negotiate a phased launch'] },
                { type: 'text', prompt: 'How do you present the "Phased Launch" idea to a frustrated client?' }
            ]
        },
        {
            title: 'Budget Cut Impact',
            jobRole: 'Project Manager',
            difficulty: 'Medium',
            description: 'Management just cut your testing budget by 40%.',
            stages: [
                { type: 'ranking', prompt: 'What do you cut first?', options: ['Automated Tests', 'Manual QA Contract', 'Beta Testing Phase'] },
                { type: 'text', prompt: 'Propose a "Risk-Based Testing" strategy to your manager.' }
            ]
        },
        {
            title: 'Agile Transformation',
            jobRole: 'Project Manager',
            difficulty: 'Easy',
            description: 'Your team is switching from Waterfall to Scrum. They don\'t see the point of standups.',
            stages: [
                { type: 'text', prompt: 'Explain the value of a 15-min standup to a skeptic in one paragraph.' }
            ]
        },

        // HR
        {
            title: 'Conflict in Marketing',
            jobRole: 'HR',
            difficulty: 'Medium',
            description: 'An anonymous report claims a Manager is being "unnecessarily harsh" during reviews.',
            stages: [
                { type: 'mcq', prompt: 'First action?', options: ['Interview the Manager', 'Interview the team members', 'Ignore anonymous reports'] },
                { type: 'text', prompt: 'Describe how you will handle the feedback session with the Manager to ensure growth, not defensiveness.' }
            ]
        },
        {
            title: 'Diversity & Inclusion',
            jobRole: 'HR',
            difficulty: 'Easy',
            description: 'The company wants to improve its hiring pipeline to be more inclusive.',
            stages: [
                { type: 'text', prompt: 'Suggest 2 specific changes to the job description wording to attract diverse talent.' }
            ]
        },
        {
            title: 'The Great Resignation',
            jobRole: 'HR',
            difficulty: 'Hard',
            description: '3 top performers resigned in one week for higher pay elsewhere.',
            stages: [
                { type: 'ranking', prompt: 'Prioritize retention tactics:', options: ['Salary adjustments', 'Flexible Work Policy', 'Stock Options', 'Career Progression clarity'] },
                { type: 'text', prompt: 'Draft a message to the CEO explaining the root cause (Retention vs Market Rate).' }
            ]
        }
    ];

    for (let s of data) {
        const role = s.jobRole.replace(/[\n\r]/g, '').trim();
        await Scenario.create({ ...s, jobRole: role, rubric: r._id });
    }

    console.log('Seeding finished successfully.');
    process.exit();
}

seed();
