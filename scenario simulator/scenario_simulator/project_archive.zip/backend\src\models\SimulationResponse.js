const mongoose = require('mongoose');

const SimulationResponseSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  scenario: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Scenario',
    required: true
  },
  stageResponses: [{
    stageIndex: Number,
    type: { type: String, enum: ['text', 'mcq', 'ranking'] },
    answer: mongoose.Schema.Types.Mixed, // String, Index, or Array of indices
    timestamp: { type: Date, default: Date.now }
  }],
  rawInput: {
    type: String, // Full concatenated transcript for AI summarization
  },
  aiSummarizedInput: {
    type: [String], // Array of bullet points
    default: []
  },
  competencyScores: [{
    competency: String,
    observedParameters: [String], // Keywords matched
    status: {
      type: String,
      enum: ['Observed', 'Not Observed', 'Partial'],
      default: 'Not Observed'
    },
    feedback: String
  }],
  aiFeedback: {
    type: String, // General coherence/communication feedback
  },
  sharedWith: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  completedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('SimulationResponse', SimulationResponseSchema);
