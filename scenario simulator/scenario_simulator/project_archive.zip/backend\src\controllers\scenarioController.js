const Scenario = require('../models/Scenario');

// @desc    Get all scenarios
// @route   GET /api/scenarios
// @access  Private
exports.getScenarios = async (req, res) => {
    try {
        const { jobRole } = req.query;
        console.log('--- SCENARIO FETCH START ---');
        console.log('Query JobRole:', jobRole);

        let query = {};
        if (jobRole && jobRole !== 'None' && jobRole !== 'undefined') {
            // Trim and replace newlines to be safe
            const cleanRole = jobRole.replace(/[\n\r]/g, '').trim();
            query.jobRole = { $regex: new RegExp(`^${cleanRole}$`, 'i') };
        }

        const scenarios = await Scenario.find(query).sort({ order: 1 });
        console.log(`SCENARIO FETCH COMPLETE: Found ${scenarios.length} items for query.`);

        if (scenarios.length === 0) {
            const allScenarios = await Scenario.find();
            console.log('TOTAL SCENARIOS IN DATABASE:', allScenarios.length);
        }

        res.status(200).json({ success: true, count: scenarios.length, data: scenarios });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};

// @desc    Get single scenario
// @route   GET /api/scenarios/:id
// @access  Private
exports.getScenario = async (req, res) => {
    try {
        const scenario = await Scenario.findById(req.params.id);
        if (!scenario) {
            return res.status(404).json({ success: false, error: 'Scenario not found' });
        }
        res.status(200).json({ success: true, data: scenario });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};

// @desc    Get unique job roles
// @route   GET /api/scenarios/roles
// @access  Private
exports.getUniqueRoles = async (req, res) => {
    try {
        const roles = await Scenario.distinct('jobRole');
        res.status(200).json({ success: true, data: roles.sort() });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};

// @desc    Create scenario (seeds or admin)
// @route   POST /api/scenarios
// @access  Private/Admin
exports.createScenario = async (req, res) => {
    try {
        // Basic validation for stages
        if (!req.body.stages || req.body.stages.length === 0) {
            return res.status(400).json({ success: false, error: 'At least one stage is required' });
        }

        // Auto-assign first rubric if not provided
        if (!req.body.rubric) {
            const Rubric = require('../models/Rubric');
            const defaultRubric = await Rubric.findOne();
            if (defaultRubric) req.body.rubric = defaultRubric._id;
        }

        const scenario = await Scenario.create(req.body);
        res.status(201).json({ success: true, data: scenario });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};
