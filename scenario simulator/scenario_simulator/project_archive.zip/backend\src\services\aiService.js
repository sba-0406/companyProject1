const { GoogleGenerativeAI } = require("@google/generative-ai");
const OpenAI = require('openai');

// Advanced Prompt Templates for "Wow Factor" Feedback
const SUMMARIZE_TEMPLATE = `
Analyze the following professional simulation transcript. 
Extract 3-5 concise, evidence-based bullet points of what the user DID.
Focus on actions, specific decisions, and tone.
Example: 'Used a collaborative tone when unblocking developers.'
Transcript:
`;

const IMPACT_ANALYZE_TEMPLATE = (role) => `
You are a Senior Executive and Mentor evaluating a ${role} in a high-stakes simulation.
Analyze the transcript and provide a structured impact analysis. 

Strict Requirements:
1. Identify 3 core competencies relevant to a ${role}.
2. For each, give a score (1-10) and the EXACT EVIDENCE (quote or specific action) from the transcript.
3. Provide a 'Mentor's Insight' (Overall feedback) that is professional and encouraging.

Return ONLY a JSON object in this format:
{
  "scores": [
    { "competency": "string", "score": number, "evidence": "string" }
  ],
  "overallFeedback": "string"
}

Transcript:
`;

class GeminiAIService {
  constructor(apiKey) {
    this.genAI = new GoogleGenerativeAI(apiKey);
    this.model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  }

  async summarize(text) {
    try {
      const prompt = SUMMARIZE_TEMPLATE + text;
      const result = await this.model.generateContent(prompt);
      const output = result.response.text();
      return output.split('\n').filter(line => line.trim().startsWith('-') || line.trim().match(/^\d\./)).map(s => s.replace(/^[- \d.]+/, '').trim());
    } catch (err) {
      console.error("Gemini Summarize Error:", err);
      return ["Analysis unavailable - check API configuration."];
    }
  }

  async analyzeImpact(transcript, jobRole) {
    try {
      const prompt = IMPACT_ANALYZE_TEMPLATE(jobRole) + transcript;
      const result = await this.model.generateContent(prompt);
      const text = result.response.text();
      // Clean JSON string in case of markdown blocks
      const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
      return JSON.parse(cleaned);
    } catch (err) {
      console.error("Gemini Impact Error:", err);
      return { scores: [], overallFeedback: "Technical assessment pending manual review." };
    }
  }
}

class OpenAI_AIService {
  constructor(apiKey) {
    this.openai = new OpenAI({ apiKey });
  }

  async summarize(text) {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: SUMMARIZE_TEMPLATE }, { role: "user", content: text }],
        temperature: 0.5,
      });
      return response.choices[0].message.content.split('\n').filter(line => line.trim().length > 0);
    } catch (err) { return ["Transcript analysis currently unavailable."]; }
  }

  async analyzeImpact(transcript, jobRole) {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: IMPACT_ANALYZE_TEMPLATE(jobRole) }, { role: "user", content: transcript }],
        response_format: { type: "json_object" }
      });
      return JSON.parse(response.choices[0].message.content);
    } catch (err) { return { scores: [], overallFeedback: "Assessment unavailable." }; }
  }
}

class MockAIService {
  async summarize(text) {
    return [
      "User addressed immediate stakeholder needs.",
      "User prioritized system stability.",
      "User communicated clear next steps."
    ];
  }
  async analyzeImpact(transcript, jobRole) {
    return {
      scores: [
        { competency: "Decision Making", score: 8, evidence: "Promptly identified priority issues." },
        { competency: "Communication", score: 7, evidence: "Professional tone used throughout." }
      ],
      overallFeedback: "Strong performance! (Connect Gemini/OpenAI API in .env for real-time analysis)"
    };
  }
}

// Factory
const getAI = () => {
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'placeholder') {
    console.log('--- AI ENGINE: GEMINI (ACTIVE) ---');
    return new GeminiAIService(process.env.GEMINI_API_KEY);
  }
  if (process.env.OPENAI_API_KEY && !process.env.OPENAI_API_KEY.includes('placeholder')) {
    console.log('--- AI ENGINE: OPENAI (ACTIVE) ---');
    return new OpenAI_AIService(process.env.OPENAI_API_KEY);
  }
  console.log('--- AI ENGINE: MOCK (API KEY MISSING) ---');
  return new MockAIService();
};

module.exports = getAI();
