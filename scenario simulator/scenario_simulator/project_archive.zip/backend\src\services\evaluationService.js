const Scenario = require('../models/Scenario');
const Rubric = require('../models/Rubric');
const SimulationResponse = require('../models/SimulationResponse');
const aiService = require('./aiService');

exports.evaluateResponse = async (userId, scenarioId, stageResponses) => {
  // 1. Fetch Scenario
  const scenario = await Scenario.findById(scenarioId).populate('rubric');
  if (!scenario) throw new Error('Scenario not found');

  // 2. Build full transcript of user actions for AI
  let transcript = "";
  stageResponses.forEach((res, idx) => {
    const stage = scenario.stages[res.stageIndex];
    transcript += `Stage ${idx + 1} (${stage.type}):\nPrompt: ${stage.prompt}\nUser Answer: ${res.answer}\n\n`;
  });

  // 3. AI Impact Analysis (Evidence-Based)
  const analysis = await aiService.analyzeImpact(transcript, scenario.jobRole);
  const summarizedPoints = await aiService.summarize(transcript);

  // 4. Map Structured AI Scores to SimulationResponse format
  // We map the new 'Impact Analysis' scores to the existing competencyScores field
  const competencyScores = analysis.scores.map(s => ({
    competency: s.competency,
    observedParameters: [s.evidence],
    status: s.score >= 7 ? 'Observed' : (s.score >= 4 ? 'Partial' : 'Not Observed'),
    feedback: s.evidence
  }));

  // 5. Save Response
  const response = await SimulationResponse.create({
    user: userId,
    scenario: scenarioId,
    stageResponses,
    rawInput: transcript,
    aiSummarizedInput: summarizedPoints,
    competencyScores,
    aiFeedback: analysis.overallFeedback
  });

  return response;
};
