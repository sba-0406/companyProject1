const SimulationResponse = require('../models/SimulationResponse');
const User = require('../models/User');

// @desc    Get user report (self)
// @route   GET /api/reports/me
// @access  Private
exports.getMyReport = async (req, res) => {
  try {
    const responses = await SimulationResponse.find({ user: req.user.id }).populate('scenario');

    // Aggregate data for report
    // Example: Count observed competencies
    const stats = {
      totalSimulations: responses.length,
      competenciesObserved: 0,
      competenciesMissed: 0
    };

    // Simple aggregation logic
    responses.forEach(r => {
      r.competencyScores.forEach(c => {
        if (c.status === 'Observed') stats.competenciesObserved++;
        else stats.competenciesMissed++;
      });
    });

    res.status(200).json({ success: true, data: { stats, history: responses } });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};

// @desc    Get reports shared with me (Manager)
// @route   GET /api/reports/shared
// @access  Private/Manager
exports.getSharedReports = async (req, res) => {
  try {
    const responses = await SimulationResponse.find({ sharedWith: req.user.id })
      .populate('user', 'name email')
      .populate('scenario');

    res.status(200).json({ success: true, count: responses.length, data: responses });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
};
